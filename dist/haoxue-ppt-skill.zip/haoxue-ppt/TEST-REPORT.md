# 测试结果与已知限制

> 版本：1.3.0　测试日期：2026-11-16
> 结论：**自动验收 131 项全部通过；6 类交付 PPT + 10 套主题共 16 个文件，三层质检（Ghost Deck / Teaching QA / 技术质检）全部通过。**
> 本轮（1.3.0）重点：架构从"单文件规范"重组为**七层 Progressive Disclosure**（SKILL.md 只做地图，规则拆到 8 份分层文档）；新增**九种认知动作引擎**（每页标注"学生此刻该做什么"，构建期校验序列）、**Ghost Deck Test**（只读标题检验叙事，真课件 99 分 / 目录式反例 45 分）、**Teaching QA 七维评分**（<8.0 重做）、**Design DNA 提取**（参考 PPT → 六维参数，学习≠复制）；spec 新增 `meta.intent` 与 `page.cognitive`，样例全部标注。
> 上一轮（1.2.0）：元素设计升级（chip / 编号 / 收口金线 / KPI 三档字号）与十套配色重调。
> 上一轮（1.1.0）：渐变 + 双层阴影 + 真渐变遮罩、字号下限锁 16pt、六级字号阶梯。

---

## 一、测试环境

| 项 | 版本 |
|---|---|
| 操作系统 | Windows 11 |
| Node.js | v22.22.2 |
| Python | 3.13.14 |
| pptxgenjs | 3.12.0 |
| sharp | 0.34.5（可选，用于裁图与图标栅格化） |
| jszip | 3.10.2（OOXML 后处理：注入渐变与双层阴影） |
| python-pptx | 1.0.2（结构校验） |
| Spire.Presentation | 本地渲染引擎（不随包分发） |

**兼容性说明**：本机无 Microsoft PowerPoint 与 LibreOffice。兼容性证据来自三个独立实现：
① `python-pptx` 能完整解析全部交付文件（页数、形状、图表、图片关系）；② `Spire.Presentation`（商业渲染引擎）逐页渲染成功，无报错；③ 包结构校验无重复条目、无损坏条目（`zipfile.testzip()` 返回 `None`）。
**未覆盖**：PowerPoint 实机放映、WPS 实机打开。这两项需在目标机器上人工点开一次确认。

---

## 二、交付件验收对照

| # | 验收要求 | 结果 | 证据 |
|---|---|---|---|
| 1 | 至少 10 页《健康管理与营销》课件 | ✅ 11 页 | `out/健康管理与营销.pptx` |
| 2 | 至少 6 种版式 | ✅ 11 种（每页一种，无重复） | QA 输出 `cover/agenda/bigIdea/question/layers/flow/dataChart/offsetImageText/caseStory/debate/summary` |
| 3 | 含右上角课程进度导航 | ✅ 10/11 页显示（仅封面不画） | `out/main-preview/` |
| 3b | 章节胶囊式导航 | ✅ 两版可选：刻度条 / 章节胶囊 | `out/健康管理与营销-胶囊导航版.pptx`、`--nav tabs` |
| 4 | 含图页与无图页 | ✅ 有图版 2 页含插图；另有 `--image none` 无图版整册 | `out/健康管理与营销-无图版.pptx` |
| 5 | 真实案例 + 理论 + 互动 + 总结 | ✅ 第 4 页互动、第 9 页四幕案例 + 健康信念模型、第 11 页总结 | 全册截图 `out/预览-健康管理与营销.png` |
| 6 | 流程图 / 对照图 / 结构图 | ✅ `flow` / `debate` / `layers` | 第 5、6、10 页 |
| 7 | 可切换多套主题 | ✅ 10 个文件，版式结构完全一致 | `out/themes/*.pptx` |
| 8 | 无连续三栏卡片堆叠 | ✅ 全册无"三栏卡片"版式 | 全册截图 |
| 9 | 可编辑（非截图） | ✅ 文字、形状、图表全为原生对象；渐变与阴影是 `a:gradFill`/`a:outerShdw`，不是位图 | python-pptx 读取到 `chart` part 与 `sp`/`txBody` |
| 10 | 无溢出、无变形 | ✅ QA 0 error / 0 warn；图片裁切写真实 `srcRect` | `scripts/qa.py` 输出 |
| 11 | 能正常打开 | ✅ python-pptx 与 Spire 双引擎均可打开 | 见「兼容性说明」 |
| 12 | 排版可量化（留白/层级/阴影/边距） | ✅ 4 项检查全册 0 报警 | `design.js` + `qa.py` 的 `DENSITY / HIERARCHY / SHADOW / MARGIN` |
| 13 | 右上角导航不贴边 | ✅ 胶囊上留白 0.54in、底部与标题留 0.30in | 第 2–11 页截图 |
| 14 | **字号最小 16pt** | ✅ 全册（含页码、图注、导航、脚注）最小字号 = 16pt | `qa.py` 的 `FONT`；`tests` 的「整册最小字号 ≥16pt」 |
| 15 | **字号尽量统一** | ✅ 全册只用 52/34/26/21/18/16 六档；单页最多 5 种 | `tests` 的「单页字号种类 ≤5」与阶梯断言 |
| 16 | **立体化（不平面）** | ✅ 卡片 = 渐变填充 + 接触阴影 + 环境阴影；全幅页遮罩为真渐变 | `tests` 的「卡片注入渐变填充 / 双层阴影」「遮罩换成渐变填充」 |

**主题覆盖**：`slate / academic / cream / tech / forest / editorial / wine / violet / darktalk / clay` 共 10 套，每套 11 页，共 110 页全部通过质检。

---

## 三、自动质检（16 项）

`python scripts/qa.py <deck.pptx> [--preview <dir>]`

| 文件 | 页数 | 必须修复 | 需人工确认 | 提示 |
|---|---|---|---|---|
| 健康管理与营销.pptx（刻度导航） | 11 | 0 | 0 | 8 |
| 健康管理与营销-无图版.pptx | 11 | 0 | 0 | 8 |
| 健康管理与营销-胶囊导航版.pptx | 11 | 0 | 0 | 9 |
| gallery.pptx（14 版式样张） | 15 | 0 | 0 | 14 |
| themes/ 下 10 套 | 各 11 | 0 | 0 | 各 8 |

**提示的实际内容**（全部为 `info` 级，是设计意图而非缺陷）：
- 2 条 `BOUNDS`：封面装饰圆故意出血到画布外（`decor.ring.*`）；
- 6 条 `FONT`：`标题 52pt / 正文中位 16pt，层级对比强（正常）`——这是"层级健康"的确认信息，不是问题。
（胶囊导航版多 1 条：胶囊本身也有一处装饰出血。）

`gallery.pptx` 的 14 条同理（3 条装饰出血 + 11 条层级健康）。

### 本轮把两条"审美要求"变成了机器判定

| 检查 | 阈值 | 想拦住什么 |
|---|---|---|
| `FONT` 下限 | **任意文字 ≥16pt** | 为了塞内容把字号压到 13/11pt，投到教室后排就看不清 |
| `FONT` 种类 | 单页 ≤5 种 | 一页出现 8 种字号，看起来像随手排的 |
| `DENSITY` | 色块/图表覆盖 ≤55% | 一页塞满、没有呼吸（字号放大后必须同步放留白） |
| `SHADOW` | 方向 90°±15°、不透明度 ≤26% | 阴影方向打架、发黑发脏 |
| `HIERARCHY` | 最大字号 / 正文中位 ≥1.5 | 标题和正文一样大，看不出重点 |
| `MARGIN` | 正文距页边 ≥0.5in | 内容顶到页边，像打印没留白 |

---

## 四、功能自检（120 项）

`node tests/test_skill.js`

| 组 | 覆盖内容 | 结果 |
|---|---|---|
| 1 主题系统 | 10 套 token 完整、颜色 6 位十六进制、图表色 ≥4、正文对比度 ≥4.5:1 | 通过 |
| 2 版式系统 | 版式数 ≥12（实际 18）、任务书点名的 12 种齐备、每个版式有 build/name | 通过 |
| 3 主课件构建 | spec 校验、页数、版式不重复、每页有内容 | 通过 |
| 4 导航组件 | 章节序号/名称/刻度、封面不画而收束页画、深色页配色切换；胶囊模式（每章 1 个胶囊、恰好 1 个当前项、带序号徽标）、章节过多时自动退回刻度模式 | 通过 |
| 5 图片双模式 | `auto / none / existing` 三种模式行为正确、无图时不产生 image op | 通过 |
| 6 长文本自适应 | 4 倍超量正文不崩溃、**字号不低于 16pt**（不再为塞内容降到 12pt；超量交给 `qa.py` 的 `OVERFLOW` 报出来） | 通过 |
| 7 局部生成 | `--only 8` 只出 1 页、页脚仍显示 `08 / 11`、非法版式与空 pages 被拦下 | 通过 |
| 8 全主题批量 | 10 套全部构建成功、换主题不改变版式结构 | 通过 |
| 9 单页替换 | `splice.py` 换回第 8 页后页数不变、第 8 页为新内容、相邻页未被改动 | 通过 |
| 10 设计规则 | 间距阶梯递增且落在 2pt 网格、**六级字号阶梯 + 相邻比 ≥1.12 + 最小 16pt**、圆角 3 档、阴影方向统一且 ≤26%、**卡片 XML 含 gradFill 与成对 outerShdw**、**遮罩为带 alpha 停靠点的 gradFill**、`card()` 内边距与强调条（顶部条按圆角内缩）、胶囊顶部留白 ≥0.5in | 通过（本轮新增 21 项） |

---

## 五、视觉复检（人工逐页看图）

自动质检只能发现"可计算的问题"。本轮把 15 页样张逐页渲染成 PNG 放大看过，修掉的问题：

| 页 / 版式 | 看到的问题 | 修法 |
|---|---|---|
| `matrix` 四象限 | 轴标签挤成两行（`需求强度 低` 一行、`低价值/高价值` 又一行），读不出哪句属于哪个轴 | 压成两行：纵轴名贴左上/左下，横轴范围写右下；面板改用 `card()` 获得渐变 + 阴影 |
| `fullImage` 全幅页 | kicker 压在亮图上糊成一片；遮罩过渡处有十几条"梯田"横纹 | 文字整体下移进遮罩；遮罩从"多段半透明矩形"改为**一条带 alpha 停靠点的 `gradFill`**（分段矩形的每条边都会因抗锯齿露出 hairline） |
| `bento` 卡片栅格 | 顶部强调条是直角，在卡片圆角处"露头"，像贴歪的胶带 | `accentSide:'top'` 按圆角内缩 |
| `dataChart` 数据页 | 三组 KPI 的说明行被分组线穿过（像删除线）；最后一组压到结论条 | 分组线去掉，改用"大数字 + 同基线金色小标"两行结构，组距 0.17in |
| `causalChain` 因果链 | 引号被排到行首：`复评数据把"感觉 / "变成"证据"` | `measure.js` 的断行禁则补上左右引号（`"" ''`） |
| `zoom` 局部放大 | 右侧放大图内容贴到画框内边 | 确认是裁切边界而非错位；裁切保留（这是"局部放大"的语义） |

一件值得记的事：这次"平面感"的根因不在配色，而在**所有元素都贴在同一个平面上**。pptxgenjs 只能写纯色填充和单层阴影，所以渐变与双层阴影必须落到 OOXML 层去注入（`postprocess.js`），注入后依然是 PowerPoint 原生效果，WPS 里也能改。

---

## 六、附加测试

### 6.1 局部修改（只改一页，不重生成整套）

```
node scripts/build.js spec.json -o page8.pptx --only 8           # 只生成第 8 页
python scripts/splice.py deck.pptx page8.pptx 8 -o fixed.pptx   # 换回主文件
```

实测：11 页课件只重建 1 页，替换后页数仍为 11，第 8 页文案已更新，第 7 页字节级未变，图片/图标/图表关系完整（QA 0 error）。
耗时：全量 11 页 ≈ 0.28s，单页 ≈ 0.22s。**页数越多收益越明显**（每页约 20ms 的绘制 + 图片处理成本被省去）。

### 6.2 长文本

用 4 倍超量正文压测 `bigIdea / question / caseStory`：不崩溃、页数与结构正常。

**注意行为已变**：以前的做法是"一路缩字号直到塞下"，于是 4 倍正文会被压到 11–12pt——读不清，等于失败。
现在的规则是**字号优先**：最低 16pt，塞不下就让它溢出，由 `qa.py` 的 `OVERFLOW` 明确报出来。

实测（198 字塞进 `bigIdea`）：构建期无 warning，`qa.py` 报「需 4.50in / 框高 4.14in」。
这条提示的正确读法是"删字或拆页"，不是"把字号调小"。

### 6.3 缺图

`--image none` 生成整册无图版：所有图片位替换为矢量色板（色带 + 标签 + 几何装饰），不是灰框占位；QA 通过。

### 6.4 中文字体与断行

全册使用微软雅黑，文本度量按 CJK 1.0em / 全角标点 0.92em / ASCII 0.55em 建模；断行带简易禁则（标点不出现在行首、开括号不留行尾、左右引号不跨行）。标题允许用 `\n` 显式断行，关键词高亮路径用 `breakLine` 保证换行生效。

### 6.5 16:9 与可编辑性

画幅 `13.333 × 7.5 in`（比例 1.778），全册统一。所有卡片、条带、遮罩、图标都是原生形状/文本，python-pptx 可枚举到每个 `sp`。

---

## 七、已知限制

1. **图表库为自动索引，不是内置素材库。** `assets/charts/index.json` 由 `chart-index.js` 扫描用户自己的 PPTX 生成。未提供素材时，图表走「原生图表 → SVG → 文本结构」降级链。
2. **动画未实现。** 当前每页元素顺序即为建议的进入顺序，但未写 `p:timing`，PowerPoint 中不会自动播放。
3. **渲染校验依赖 Spire（评估版）。** 单册上限 10 页，`render.py` 会自动拆册分批渲染；评估版会在页面顶部 0.36in 打一行水印，默认 `--mode cut` 裁掉（预览图因此比 16:9 略矮），`--mode clean` 可抹水印保画幅。**Spire 只用于本地检图，不随包分发。**
4. **未在 PowerPoint / WPS 实机打开。** 建议首次交付前人工打开一次，重点看渐变与双层阴影（这是本轮新增的 OOXML 特性）。
5. **`splice.py` 不处理幻灯片节（section）。** 若目标文件用「节」组织页面，替换后节归属可能落到相邻页。
6. **图片裁切需要 sharp。** 未安装 sharp 时 `cover` 图退化为拉伸填充（QA 会提示），`zoom` 页放大图退化为不裁切。
7. **导航最多显示 6 个章节刻度。** 超过 6 章自动切换紧凑模式（只留序号与章节名）；`tabs` 模式在章节名过长时也退回刻度模式。
8. **`DENSITY` 只统计实心块/图片/图表，不含文字。** "文字很密但没底色"由 `OVERFLOW / OVERLAP / HIERARCHY` 兜。
9. **`MARGIN` 靠命名区分装饰。** 页边附近的装饰必须命名 `decor.*`，否则会被判为正文贴边。
10. **16pt 下限会放大"内容太多"的矛盾。** 这是刻意的：空间不够时正确做法是删字、拆页，而不是缩字号。`bento` 因此限制 3–6 个卡片，`dataChart` 限制 KPI ≤3 组，`caseStory` 理论面板最多 2 点（超出会报 `NOTE-CLIPPED` / `CARD-DENSE`）。
11. **渐变与双层阴影只在浅色主题生效。** 深色底上阴影不可见，只会留下灰边，因此 `dark` 主题自动关闭卡片阴影。

---

## 八、复现全部结论

```bash
cd haoxue-ppt
npm install

# 1) 功能自检（120 项，不需要 Python）
node tests/test_skill.js

# 2) 生成交付件
node scripts/build.js examples/health-marketing.deck.json -o "out/健康管理与营销.pptx"
node scripts/build.js examples/health-marketing.deck.json -o "out/健康管理与营销-无图版.pptx" --image none
node scripts/build.js examples/health-marketing.deck.json -o "out/健康管理与营销-胶囊导航版.pptx" --nav tabs
node scripts/build.js examples/health-marketing.deck.json --theme all -o out/themes
node scripts/build.js tests/gallery.deck.json -o out/gallery.pptx

# 3) 自动质检（16 项）
python scripts/qa.py "out/健康管理与营销.pptx"
for f in out/themes/*.pptx; do python scripts/qa.py "$f"; done

# 4) 渲染校验图 + 样张总览（需 Spire）
python scripts/render.py "out/健康管理与营销.pptx" -o out/main-preview
python scripts/sheet.py out/main-preview -o "out/预览-健康管理与营销.png"
```


## 1.4.0 · Color Engine 色彩层级引擎

**问题**：课件"素"的根因不是颜色少，而是缺少色彩层级——纯白底 + 纯黑字 + 单强调，四个颜色各自为战。

**方案**（吸收 Frontend Slides 色阶系统 + MiniMax Palette Library + Anthropic 主导权重 + DeerFlow 氛围深浅）：

- `assets/colors.json`：10 套 Color Families（C01–C10），每套只给 4 个种子色（主色/强调/纸白/墨色）
- `scripts/lib/palette.js`：4 种子 → 11 档色阶（种子基本落在 700 档）+ 三层表面（禁纯白）+ 语义色 + 配比卡 + 审计
- `theme.js`：色族优先解析（c01–c10 / id / 中文名），单色 HEX 也走色阶展开；旧主题保留为 legacy
- `scripts/palette.js`：list / show / card（选色卡 HTML）/ from（C10 从参考 PPT 四角色提取）
- `scripts/colorqa.py`：成品用色纪律量化——HUE ≤4 族 / 主导 ≥35% / 禁纯白底 / 表面 ≥2 层 / 色阶 ≥3 档 / 强调 ≤12%
- `dna.py`：新增就近色族推荐与 C10 提取命令输出
- 硬约束新增第 13 条（色彩有纪律）；示例课件切换到 c05 / c02

**验收**

| 项 | 结果 |
|---|---|
| 自检 | 213 项全过（新增 26 项 Color Engine 检查） |
| 四份交付课件 qa.py | 0 必须修复 / 0 需人工确认 |
| 四份交付课件 colorqa.py | 全部通过：少色相、有主导、有表面、有色阶 |
| Ghost Deck / Teaching QA | 87+ 分 / 9.12、8.99 通过 |
| 九套色族 palette.audit | 全过（对比度、无纯白、表面层次、明暗差） |


## 1.4.1 · 页内强调层级

**问题**：色阶解决整册层次后，单页内部仍"一页一个颜色"——正文、标题、卡片全是同一色温，看不出重点在哪。

**方案**：重点不是靠加粗，是靠颜色——普通文字是墨色，重点才是主色。

- `canvas.js`：`**关键词**` → 主色加重（em）、`!!焦点!!` → 强调色加重（emAccent）；测量按剥标记纯文本计算；深色上下文自动换 emOnDeep/accentOnDeep；text() 与 paragraphs() 双入口生效
- `theme.js`：新增 token `em` / `emAccent` / `emOnDeep`（对比度均 ≥4.5:1）
- `common.js` insightBar：白卡 → 主色浅底 + 主色正文，成为"每页的落点"
- `grid.js` bento：`em`/`tone:'tint'` 强调卡（主色浅底+主色标题+主色强调条，一页限一张）；序号升级实底圆徽章
- 示例课件加强调标记与强调卡；SKILL.md 硬约束新增第 14 条（页内必须有重点）

**验收**：自检 229 项全过（新增 16 项页内强调检查）；九套色族 × 样张 qa 全 0/0；40 页课件渲染确认重点可辨。
